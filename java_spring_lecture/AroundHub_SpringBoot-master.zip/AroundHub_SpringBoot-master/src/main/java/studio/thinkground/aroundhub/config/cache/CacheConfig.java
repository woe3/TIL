package studio.thinkground.aroundhub.config.cache;

/**
 * PackageName : studio.thinkground.aroundhub.config.cache
 * FileName : CacheConfig
 * Author : Flature
 * Date : 2022-05-19
 * Description :
 */
public interface CacheConfig {
}
